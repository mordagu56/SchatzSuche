package com.example.ufind_layout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Html;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView quoteText;
    Button searchButton;
    EditText coursePerson;
    Button bachelorStudies;
    Button masterStudies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        quoteText = findViewById(R.id.uniInfo);
        searchButton = findViewById(R.id.searchButton);
        coursePerson = findViewById(R.id.coursePersonView);
        bachelorStudies = findViewById(R.id.bachelorButton);
        masterStudies = findViewById(R.id.masterButton);

    }
}