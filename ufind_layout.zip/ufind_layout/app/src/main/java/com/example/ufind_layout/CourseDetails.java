package com.example.ufind_layout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CourseDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_details);
    }
}